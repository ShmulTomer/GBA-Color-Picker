/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=7x7 cursor cursor.jpeg 
 * Time-stamp: Tuesday 11/08/2022, 15:16:39
 * 
 * Image Information
 * -----------------
 * cursor.jpeg 7@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CURSOR_H
#define CURSOR_H

extern const unsigned short cursor[49];
#define CURSOR_SIZE 98
#define CURSOR_LENGTH 49
#define CURSOR_WIDTH 7
#define CURSOR_HEIGHT 7

#endif

