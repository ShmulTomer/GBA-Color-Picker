/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x15 square square.png 
 * Time-stamp: Tuesday 11/08/2022, 05:00:57
 * 
 * Image Information
 * -----------------
 * square.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SQUARE_H
#define SQUARE_H

extern const unsigned short square[225];
#define SQUARE_SIZE 450
#define SQUARE_LENGTH 225
#define SQUARE_WIDTH 15
#define SQUARE_HEIGHT 15

#endif

