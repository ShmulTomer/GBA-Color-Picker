/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 palette palette.jpeg 
 * Time-stamp: Monday 11/07/2022, 15:16:23
 * 
 * Image Information
 * -----------------
 * palette.jpeg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PALETTE_H
#define PALETTE_H

extern const unsigned short palette[38400];
#define PALETTE_SIZE 76800
#define PALETTE_LENGTH 38400
#define PALETTE_WIDTH 240
#define PALETTE_HEIGHT 160

#endif

